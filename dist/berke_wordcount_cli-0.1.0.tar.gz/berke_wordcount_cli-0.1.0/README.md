# wordcount-cli

Tiny Python CLI that prints line, word, and character counts for a text file.

## Features

- Count lines
- Count words
- Count characters
- Friendly CLI output
- Single-value flags for scripting

## Installation

```bash
pip install -e .